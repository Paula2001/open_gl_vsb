#pragma once
class StringMan
{
	public:
		static const char* replace(const char* needle,const char* replace,const char* origin);
};

