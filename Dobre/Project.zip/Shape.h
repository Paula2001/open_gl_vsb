#pragma once
class Shape
{
};

